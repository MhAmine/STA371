# Load the mosaic library
library(mosaic)

## Load the data on orchard sprays
# OrchardSprays = read.csv("OrchardSprays.csv")

# Calculate the group means.
# You must load the mosaic package to use the following command
mean(decrease~treatment, data=OrchardSprays)

GroupMeans = mean(decrease~treatment, data=OrchardSprays)

# Make a dot plot/strip chart showing the group-wise data
dotplot(decrease~treatment, data=OrchardSprays,
	xlab="Concentration of Lime Sulphur (A = highest; H = none)",
	ylab="Decrease in volume of solution")
