library(mosaic)

## Train/test split (challenge question)

utilities = read.csv('http://jgscott.github.com/STA371/data/utilities.csv')

N = nrow(utilities)
Ntrain = 59	## About 50% of the data used to train, 50% to test
Ntest = N - Ntrain

# Sample the overall data set to create a training set
trainset = sample(1:N, Ntrain)

# Pick out the appropriate rows of the data frame for the training set
util.train = utilities[trainset,]

# And the rest for the test set
util.test = utilities[-trainset,]

# Fit models using only the training data
lm1 = lm(gasbill~temp,data=util.train)
lm2 = lm(gasbill~temp+I(temp^2),data=util.train)

# Predict on the testing data
pred1 = predict(lm1,newdata=util.test)
pred2 = predict(lm2,newdata=util.test)

# Compute each model's mean-squared error
mse1 = mean((pred1 - util.test$gasbill)^2)
mse2 = mean((pred2 - util.test$gasbill)^2)

# Which is smaller?
c(mse1, mse2)


# "for" loops!  Try taking this as a template
# and changing to "guts" inside the for loop
# to reflect the above

# See the following for a little description of for loops
# http://paleocave.sciencesortof.com/2013/03/writing-a-for-loop-in-r/

# How many simulations do we want?
nSims = 100

# Create a placeholder matrix
mysim = matrix(0, nrow=nSims, ncol=3)
for(i in 1:nSims)
{
	# Simulate three normals with different means
	val1 = rnorm(1, 0, 1)
	val2 = rnorm(1, 1, 1)
	val3 = rnorm(1, 2, 1)
	
	# Store these three values row i of the placeholder matrix
	mysim[i,] = c(val1, val2, val3)
}

# Inspect each column
hist(mysim[,1])
hist(mysim[,2])
hist(mysim[,3])


# You can also accomplish this with mosaic's do command
mysim = do(1000)*{
	val1 = rnorm(1, 0, 1)
	val2 = rnorm(1, 1, 1)
	val3 = rnorm(1, 2, 1)
	c(val1, val2, val3)
}
hist(mysim[,1])
hist(mysim[,2])
hist(mysim[,3])
